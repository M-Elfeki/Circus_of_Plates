import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.KeyStroke;


public class Person extends JPanel
{
	private static final long serialVersionUID = 1L;
	private Point p1 = new Point(100, 100);
	private Point p2 = new Point(300, 390);
	private Stick leftStick, rightStick;
	public final static int HIEGHT_LIMIT = 390;
	private JFrame parent;
	
	public Person(String firstController, String secondController)
	{
		this.setPreferredSize(new Dimension(300, 290));
		this.setBackground(Color.white);
		this.add(new ControlPanel(firstController, secondController));
		parent = Gui.f;
		leftStick = new Stick(p2.x+20);
		rightStick = new Stick(p2.x+100);
	}
	

	@Override
    protected void paintComponent(Graphics g) {
		super.paintComponent(g);
        try 
		{
			BufferedImage img = ImageIO.read(new File("/home/mohamed/workspace/University Work/test/src/clown.png"));
			int w = img.getWidth(null);
			int h = img.getHeight(null);
			g.drawImage(img, p1.x, p1.y, p2.x, p2.y, 0, 0, w*2, h*2, null);
			try{
				leftStick.xPos = p2.x+20;
				rightStick.xPos = p2.x+100;
				leftStick.repaint();
				rightStick.repaint();
//				parent.getContentPane().add(rightStick, BorderLayout.CENTER);
//				parent.getContentPane().add(leftStick, BorderLayout.CENTER);
//				parent.getContentPane().add(this, leftStick);
//				parent.getContentPane().add(this, rightStick);
			}catch(Exception ex){}
		} catch (IOException e) {}
    }
	
	
	private class ControlPanel extends JPanel 
	{
		private static final long serialVersionUID = 1L;
		private static final int DELTA = 10;
		
        public ControlPanel(String firstController, String secondController) 
        {
        	MoveButton m1 =null;
        	MoveButton m2 =null;
        	if(firstController.equals("left")&&secondController.equals("right"))
        	{
        		m1 = new MoveButton("", KeyEvent.VK_LEFT, -DELTA);
        		m2 = new MoveButton("", KeyEvent.VK_RIGHT, DELTA);
        		this.add(m1);
                this.add(m2);
        	}
        	else if(firstController.equals("a")&&secondController.equals("d"))
        	{
                m1 = new MoveButton("", KeyEvent.VK_A, -DELTA);
        		m2 = new MoveButton("", KeyEvent.VK_D, DELTA);
        		this.add(m1);
                this.add(m2);
        	}
        	else if(firstController.equals("j")&&secondController.equals("l"))
        	{
        		m1 = new MoveButton("", KeyEvent.VK_J, -DELTA);
        		m2 = new MoveButton("", KeyEvent.VK_L, DELTA);
        		this.add(m1);
                this.add(m2);
        	}
        	else if(firstController.equals("1")&&secondController.equals("0"))
        	{
        		m1 = new MoveButton("", KeyEvent.VK_1, -DELTA);
        		m2 = new MoveButton("", KeyEvent.VK_0, DELTA);
        		this.add(m1);
                this.add(m2);
        	}
        	if(m1!=null&&m2!=null)
        	{
        		this.remove(m1);
            	this.remove(m2);
        	}
        }

        private class MoveButton extends JButton 
        {
			private static final long serialVersionUID = 1L;
			KeyStroke k;
            int dx;

            public MoveButton(String name, int code, final int dx) 
            {
                this.k = KeyStroke.getKeyStroke(code, 0);
                this.dx = dx;
                this.setAction(new AbstractAction(this.getText()) 
                {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        Person.this.p1.translate(dx, 0);
                        Person.this.p2.translate(dx, 0);
                        Person.this.repaint();
                    }
                });
                ControlPanel.this.getInputMap(WHEN_IN_FOCUSED_WINDOW).put(k, k.toString());
                ControlPanel.this.getActionMap().put(k.toString(), new AbstractAction() 
                {
                    @Override
                    public void actionPerformed(ActionEvent e) 
                    {
                        MoveButton.this.doClick();
                    }
                });
            }
        }
    }
	
}
