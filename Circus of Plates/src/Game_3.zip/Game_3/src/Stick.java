import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.util.Stack;

import javax.swing.JPanel;


public class Stick extends JPanel
{
	
	private static final long serialVersionUID = 1L;
	private Stack<Shape> stick;
	private int repsNumber = 0;
	private double stickHeight =0;
	public int xPos =0;
	
	public int getRepsNumber() {
		return repsNumber;
	}
	public Stack<Shape> getStick() {
		return stick;
	}

	public Stick(int xPosition)
	{
		this.setPreferredSize(new Dimension(50,20));
		setLayout(new FlowLayout());
		stick = new Stack<Shape>();
		xPos = xPosition;
	}
	
	@SuppressWarnings("static-access")
	private void removeRepetations()
	{
		if(stick.size()>2)
		{
			for(int i = 0;i<stick.size()-3;i++)
			{
				if(stick.get(i).getColor().equals(stick.get(i+1).getColor().equals(stick.get(i+2).getColor())))
				{
					repsNumber++;
					stickHeight-=(stick.get(i).height+stick.get(i+1).height+stick.get(i+2).height);
					i+=2;
					stick.pop();
					stick.pop();
					stick.pop();
				}
			}
		}
	}
	
	
	@SuppressWarnings("static-access")
	public void addShape(Shape s)
	{
		stickHeight+=s.height;
		stick.push(s);
	}
	
	
	
	public void paintComponent( Graphics g)
	{
		Graphics2D g2 = (Graphics2D) g;
	    g2.setColor(Color.red);
		if(stickHeight<120)
		{
			removeRepetations();
			Rectangle2D plate = new Rectangle2D.Double(xPos,85,(60),(20));
		    g2.fill(plate);
		}
	}

}
