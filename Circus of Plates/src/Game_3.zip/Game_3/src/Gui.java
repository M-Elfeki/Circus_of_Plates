import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


public class Gui 
{
	public static JFrame f;
	private JPanel gamePanel;
	private JPanel displayPanel;
	private JButton createPlayer;
	private JLabel timer; 
	private int time=0;
	private ArrayList<JLabel> scoreLabels;
	private ArrayList<Integer> scoreValues;
	private int playersNumber =0;
	
	
	public Gui()
	{
		f = new JFrame();
		f.getContentPane().setBackground(Color.white);
		gamePanel = new JPanel();
		gamePanel.setBackground(Color.white);
		gamePanel.setPreferredSize(new Dimension(800, 300));
		f.setLayout(new BorderLayout());
		f.setTitle("Circut of Plates");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setSize(800,700);
		f.setVisible(true);
		displayPanel = northPanel();
		f.add(displayPanel);
		scoreLabels = new ArrayList<JLabel>();
		scoreValues = new ArrayList<Integer>();
		new startTimer();
	}
	
	class startTimer implements Runnable 
	{
		   Thread t;
		   startTimer() 
		   {
		      t = new Thread(this, "Demo Thread");
		      t.start(); 
		   }
		   
		   public void run() 
		   {
		      try 
		      {
		         for(int i = 20000; i >= 0; i--) 
		         {
		            timer.setText("Timer: "+Integer.toString(i));
		            Thread.sleep(50);
		         }
		     } catch (InterruptedException e) {}
		      JOptionPane.showMessageDialog(null, "Game Over");
		      System.exit(0);
		   }
		   
	}
	
	
	private JPanel northPanel()
	{
		JPanel northPanel = new JPanel();
		northPanel.setLayout(new FlowLayout());
		northPanel.setSize(800, 50);
		northPanel.setBackground(Color.white);
		northPanel.setVisible(true);
		String t = "Timer:  "+ Integer.toString(time);
		timer = new JLabel(t);
		timer.setPreferredSize(new Dimension(350, 30));
		northPanel.add(timer);
		createPlayer = new JButton("Create Player");
		createPlayer.setPreferredSize(new Dimension(300, 50));
		createPlayer.addActionListener(newPlayer);
		northPanel.add(createPlayer);
		return northPanel;
	}
	
	ActionListener newPlayer = new ActionListener()
	{
		@Override
		public void actionPerformed(ActionEvent e) 
		{
			EventQueue.invokeLater(new Runnable()
			{
	            @Override
	            public void run() 
	            {   
	            	try
	            	{
	            		String input = JOptionPane.showInputDialog("Please Choose your Controllers");
	            		Person p = null;
		            	if(input.equals("right left")||input.equals("left right"))
		            		p = new Person("left", "right");
		            	else if(input.equals("a d")||input.equals("d a"))
		            		p = new Person("a", "d");
		            	else if(input.equals("1 0")||input.equals("0 1"))
		            		p = new Person("1", "0");
		            	else if(input.equals("j l")||input.equals("l j"))
		            		p = new Person("j", "l");
		            	else
		            		JOptionPane.showMessageDialog(null, "Invalid Input");
		            	if(p!=null)
		            	{
		            		gamePanel.add(p);
		            		scoreValues.add(0);
		            		String labelString = ("Player#"+Integer.toString(playersNumber+1)+" : "
		            									   +Integer.toString(scoreValues.get(playersNumber))+"          ");
		            		JLabel lbl = new JLabel(labelString);
		            		displayPanel.add(lbl);
		            		scoreLabels.add(lbl);
		            		playersNumber++;
		            	}	
		                f.add(gamePanel, BorderLayout.SOUTH);
		                f.pack();
		                f.setSize(800,700);
	            	}catch(Exception ex){}
	            }
	        });
		}
	};
	
	
	public static void main(String[] args) 
	{
		new Gui();
	}
}
